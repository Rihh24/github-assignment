

function hide(cookieDiv){
    var div=document.querySelector(cookieDiv);
    div.remove();
}