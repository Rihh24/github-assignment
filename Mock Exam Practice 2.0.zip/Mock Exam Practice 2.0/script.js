console.log("javascript is here!")

function changeBGC(){
    var strawberry= document.querySelector("#gray-text")
    strawberry.style.backgroundColor= "pink"
}