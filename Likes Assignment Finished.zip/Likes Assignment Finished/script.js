console.log("page loading....");


var count = 9;
var countElement = document.querySelector("#like1");

function like1(){
    count ++;
    countElement.innerText = count + " like(s)";
}

var count2 = 12;
var countElement2 = document.querySelector("#like2");

function like2(){
    count2 ++;
    countElement2.innerText = count2 + " like(s)"
}

var count4 = 9;
var countElement4 = document.querySelector("#like4");

function like4(){
    count4 ++;
    countElement4.innerText = count4 + " like(s)"
}